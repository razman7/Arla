<?php
  /**
  * Template Name: Stats page
  */
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <style><?php include 'style2.css'; ?> </style>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <title>Arlagården</title>
  </head>
  <body>
  <!-- DESKTOP VERSION !-->
  <div class="deskwrapper">
    <div class="stickytop"></div>
    <nav class="sidenav"> <!-- desktop menu !-->
      <div>
      <a href="https://arla.antoneliza.dk/" id="home"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/logo.svg" alt="arla logo" style="width: 100px;
  height: 200px;"></a>
      <a href="https://arla.antoneliza.dk/" id="catnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuCategories.svg" alt="arla logo"><p>Categories</p></a>
      <a href="https://arla.antoneliza.dk/final-result/" id="statnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuStatistics.svg" alt="arla logo"><p>Statistics</p></a>
      <a href="#" id="helpnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuHelp.svg" alt="arla logo"><p>Help</p></a>
      </div>
    </nav>

    <div class="deskcontent" id="sswhiteback">
      <h1 class="deskmaintitles" id="surveytitle">You've completed the <span>Imported Feeds</span> section</h1>
      <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/importFeedMainGraph.svg" alt="bar graph" class="ssimg">

      <div id="finals">
        <h2 class="sshead">FINAL RESULT: <span>0,3596 C/kg milk</span></h2>
        <h2 class="sshead2">LAST YEAR RESULT: <span style="color: #006C3A;">0,3996 C/kg milk</span></h2>
        <p>Congratulations, you did better than last year. You have reduced 0.0400 C/KG milk.
        Here are some statististics of your imputs compared to last year. Seems like you have improved in every aspect from last year.  Good job!
        </p>
      </div>

      <div class="ssbuttgrid">
        <a href="https://arla.antoneliza.dk/" class="ssbutt">BACK TO CATEGORIES</a>
        <a href="https://arla.antoneliza.dk/final-result" class="ssbutt" id="ssb2">FINISH SURVEY</a>
      </div>

      <div class="lines">
        <hr class="line1"> <p class="linetitle">INPUT STATS</p> <hr class="line2">
      </div>

      <div class="contentflex">

        <div class="ssstatgrid">
          <h2 class="sshead">MILK</h2>
          <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-39.png" alt="milk" class="sssgi">
          <div class="sssflex">
            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/importFeedMilkGraph.svg" alt="milk">
            <h2 class="sshead2">THIS YEAR RESULT: 0,3456 C/kg milk</h2>
            <h2 class="sshead2" style="opacity: .5;">LAST YEAR RESULT: 0,3121 C/kg milk</h2>
          </div>
        </div>
        <div class="ssstatgrid">
          <h2 class="sshead">COWS</h2>
          <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/cowIcon.svg" alt="milk" class="sssgi">
          <div class="sssflex">
            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/importFeedCowGraph.svg" alt="milk">
            <h2 class="sshead2">THIS YEAR RESULT: 0,2987 C/kg milk</h2>
            <h2 class="sshead2" style="opacity: .5;">LAST YEAR RESULT: 0,2279 C/kg milk</h2>
          </div>
        </div>
        <div class="ssstatgrid">
          <h2 class="sshead">ENERGY</h2>
          <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/energyIcon.svg" alt="milk" class="sssgi">
          <div class="sssflex">
            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/importFeedEnergyGraph.svg" alt="milk">
            <h2 class="sshead2">THIS YEAR RESULT: 0,4824 C/kg milk</h2>
            <h2 class="sshead2" style="opacity: .5;">LAST YEAR RESULT: 0,3956 C/kg milk</h2>
          </div>
        </div>

        </div>
    </div>
  </div>

  <!-- MOBILE VERSION !-->
  <div class="container"> <!-- mobile menu !-->
    <div class="content">
      <div role="navigation" id="topbar">
          <div id="menuToggle">
            <input type="checkbox" />
              <span></span>
              <span></span>
              <span></span>
            <nav id="menu">
              <a href="https://arla.antoneliza.dk/"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuCategories.svg" alt="arla logo"><p>Categories</p></a>
              <a href="https://arla.antoneliza.dk/final-result/"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuStatistics.svg" alt="arla logo"><p>Statistics</p></a>
              <a href="#"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuHelp.svg" alt="arla logo"><p>Help</p></a>
            </nav>
          </div>
          <div id="smallgrid">
            <a href="https://arla.antoneliza.dk/" class="logolink">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/logo.svg" alt="arla logo" id="logo">
            </a>
            <div id="rightnav">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/mobileListIcon.svg" alt="arla logo">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/mobileNavIcon.svg" alt="arla logo">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/searchGreen.svg" alt="arla logo">
            </div>
          </div>
      </div>
    </div>

    <div class="contentscroll" >
      <div class="contentflex" id="surveyflexm">
        <h2 class="maintitles">You've completed the <span>Imported Feeds</span> section</h2>
        <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/importFeedMainGraph.svg" alt="bar graph" class="ssimg" style="display: block; margin-left: auto; margin-right: auto">
        <h2 class="sshead">FINAL RESULT: <span>0,3596 C/kg milk</span></h2>
        <h2 class="sshead2">LAST YEAR RESULT: <span style="color: #006C3A;">0,3996 C/kg milk</span></h2>
        <p class="sspara">Congratulations, you did better than last year. You have reduced 0.0400 C/KG milk.
Here are some statististics of your imputs compared to last year. Seems like you have improved in every aspect from last year.  Good job!
        </p>
        <div class="ssbuttgrid">
          <a href="https://arla.antoneliza.dk/" class="ssbutt">BACK TO CATEGORIES</a>
          <a href="https://arla.antoneliza.dk/final-result" class="ssbutt" id="ssb2">NEXT CATEGORY</a>
        </div>

        <div class="lines">
          <hr class="line1"> <p class="linetitle">INPUT STATS</p> <hr class="line2">
        </div>

        <div class="ssstatgrid">
          <h2 class="sshead">MILK</h2>
          <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-39.png" alt="milk" class="sssgi">
          <div class="sssflex">
            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/importFeedMilkGraph.svg" alt="milk">
            <h2 class="sshead2">THIS YEAR RESULT: 0,3456 C/kg milk</h2>
            <h2 class="sshead2" style="opacity: .5;">LAST YEAR RESULT: 0,3121 C/kg milk</h2>
          </div>
        </div>
        <div class="ssstatgrid">
          <h2 class="sshead">COWS</h2>
          <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/cowIcon.svg" alt="milk" class="sssgi">
          <div class="sssflex">
            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/importFeedCowGraph.svg" alt="milk">
            <h2 class="sshead2">THIS YEAR RESULT: 0,2987 C/kg milk</h2>
            <h2 class="sshead2" style="opacity: .5;">LAST YEAR RESULT: 0,2279 C/kg milk</h2>
          </div>
        </div>
        <div class="ssstatgrid">
          <h2 class="sshead">ENERGY</h2>
          <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/energyIcon.svg" alt="milk" class="sssgi">
          <div class="sssflex">
            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/importFeedEnergyGraph.svg" alt="milk">
            <h2 class="sshead2">THIS YEAR RESULT: 0,4824 C/kg milk</h2>
            <h2 class="sshead2" style="opacity: .5;">LAST YEAR RESULT: 0,3956 C/kg milk</h2>
          </div>
        </div>

        <div id="onlyheresothatitscrollsnormally"></div>
      </div>
    </div>

  </div>

  </body>
</html>
