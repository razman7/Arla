<?php
  /**
  * Template Name: Arla homepage
  */
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
      <style><?php include 'style2.css'; ?> </style>
      
     
    <title>Arlagården</title>
  </head>
  
  <body>

  <div class="deskwrapper">
    <div class="stickytop"></div>
    <nav class="sidenav"> <!-- desktop menu !-->
      <div>
      <a href="https://arla.antoneliza.dk/" id="home"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/logo.svg" alt="arla logo" style="width: 100px;
  height: 200px;"></a>
      <a href="https://arla.antoneliza.dk/" id="catnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuCategories.svg" alt="arla logo"><p>Categories</p></a>
      <a href="https://arla.antoneliza.dk/final-result/" id="statnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuStatistics.svg" alt="arla logo"><p>Statistics</p></a>
      <a href="#" id="helpnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuHelp.svg" alt="arla logo"><p>Help</p></a>
      </div>
    </nav>

    <div class="deskcontent">
      <div class="search"><p>Search</p><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/search.svg" alt="search"></div>
      <h1 class="deskmaintitles">Arlagården Plus Survey</h1>
      <p class="deskmainparagraphs">Hey Henry! Welcome to our survey. Here you can see your carbon footprint. The survey has four categories, start from the top or choose one to fill in first! Each one has a progress bar which shows how far you got last time.
      </p>
      <hr class="deskline1"> <p class="desklinetitle">CATEGORIES</p> <hr class="deskline2">
      <div class="contentflex">

        <div class="deskcat">
          <div class="category">
            <a href="#"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-59.png" alt=""></a>
            <a href="#" class="butt"> COMPLETED </a>
          </div>
          
        </div>

        <div class="deskcat">
          <div class="category">
            <a href="#"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-58-1.svg" alt=""></a>
            <a href="#" class="butt"> START </a>
          </div>
          
        </div>

        <div class="deskcat">
          <div class="category">
            <a href="https://arla.antoneliza.dk/survey-page/"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-38.svg" alt=""></a>
            <a href="https://arla.antoneliza.dk/survey-page/" class="butt"> START </a>
          </div>
          <a class="overlay" href="https://arla.antoneliza.dk/survey-page/"></a>
        </div>

        <div class="deskcat">
          <div class="category">
            <a href="#"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-57-1.svg" alt=""></a>
            <a href="#" class="butt"> START </a>
          </div>
        </div>
      </div>
    </div>
  </div>



  <div class="container"> <!-- mobile menu !-->
    <div class="content">
      <div role="navigation" id="topbar">
          <div id="menuToggle">
            <input type="checkbox" />
              <span></span>
              <span></span>
              <span></span>
            <nav id="menu">
              <a href="https://arla.antoneliza.dk/"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuCategories.svg" alt="arla logo"><p>Categories</p></a>
              <a href="https://arla.antoneliza.dk/final-result/"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuStatistics.svg" alt="arla logo"><p>Statistics</p></a>
              <a href="#"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuHelp.svg" alt="arla logo"><p>Help</p></a>
            </nav>
          </div>
          <div id="smallgrid">
            <a href="#" class="logolink">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/logo.svg" alt="arla logo" id="logo">
            </a>
            <div id="rightnav">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/mobileListIcon.svg" alt="arla logo">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/mobileNavIcon.svg" alt="arla logo">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/searchGreen.svg" alt="arla logo">
            </div>
          </div>
      </div>
    </div>

    <div class="contentscroll">
      <h1 class="maintitles">Arlagården Plus Survey</h1>
      <p class="mainparagraphs">Hey Henry! Welcome to the Arlagården Plus Survey, where you can see your current and past carbon footprint.
        This survey is divided in four categories, each one regarding a specific topic. Start from the top, or choose the section you would like to fill-in!
        Each category has a progress bar, which shows how far you got last time you filled the form.
      </p>

      <div class="lines">
        <hr class="line1"> <p class="linetitle">CATEGORIES</p> <hr class="line2">
      </div>

      <div class="wrapper">
        <div class="category">
          <a href="#"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-59.png" alt=""></a>
          <a href="#" class="butt"> COMPLETED </a>
        </div>
      </div>

      <div class="wrapper">
        <div class="category">
          <a href="#"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-58-1.svg" alt="">
          <a href="#" class="butt"> START </a>
        </div>
      </div>

      <div class="wrapper">
        <div class="category">
          <a href="https://arla.antoneliza.dk/survey-page/"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-38.svg" alt="">
          <a href="https://arla.antoneliza.dk/survey-page/" class="butt"> START </a>
        </div>
      </div>

      <div class="wrapper">
        <div class="category">
          <a href="#"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-57-1.svg" alt="">
          <a href="#" class="butt"> START </a>
        </div>
      </div>
      <div id="onlyheresothatitscrollsnormally"></div>
    </div>

  </div>


  </body>
</html>
