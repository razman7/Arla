<?php
  /**
  * Template Name: Survey page
  */
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <style><?php include 'style2.css'; ?> </style>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <title>Arlagården</title>
  </head>
  <body>
  <!-- DESKTOP VERSION !-->
  <div class="deskwrapper">
    <div class="stickytop"></div>
    <nav class="sidenav"> <!-- desktop menu !-->
      <div>
      <a href="https://arla.antoneliza.dk/" id="home"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/logo.svg" alt="arla logo" style="width: 100px;
  height: 200px;"></a>
      <a href="https://arla.antoneliza.dk/" id="catnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuCategories.svg" alt="arla logo"><p>Categories</p></a>
      <a href="#" id="statnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuStatistics.svg" alt="arla logo"><p>Statistics</p></a>
      <a href="#" id="helpnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuHelp.svg" alt="arla logo"><p>Help</p></a>
      </div>
    </nav>

    <div class="deskcontent" id="whiteback">
      <a href="https://arla.antoneliza.dk/"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Frame.png" alt="back" class="backbutt"></a>
      <div class="search"><p>Search</p><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/search.svg" alt="search"></div>
      <h1 class="deskmaintitles" id="surveytitle">Imported Feed</h1>
      <p class="deskmainparagraphs" id="surveypara">In this section you will be able to fill in all
        the information necessary to calculate the CO2 produced when you import the food for you animals. <br>
        Click the field you want to fill or<b> press Enter</b> to switch between them!
      </p>
      <form class="contentflex" id="surveyflex" action="https://arla.antoneliza.dk/stats-page/">

        <div>
          <ol for="numberfloat" start="1">
            <li>How many kg of milk does one of your cows produce yearly?
              <div class="toolmark">
                <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-90.png" alt="help">
                <span class="tooltext">
                  Amount of milk produced by one of the cows on your farm. Data is <b>per year</b> and in <b>KG.</b>
                </span>
              </div>
            </li>
          <input type="number" class="numberfloat" step="any" pattern="[-+]?[0-9]*[.,]?[0-9]+" required placeholder="Click to fill!" onBlur="showProgress()"></ol>
        </div>

        <div>
          <ol for="numberfloat" start="2">
            <li>How many cows do you have in your farm?
              <div class="toolmark">
                <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-90.png" alt="help">
                <span class="tooltext">
                  Number of cows you have at this moment in your farm. Data is <b>in numbers</b>
                </span>
              </div>
            </li>
          <input type="number" class="numberfloat" step="any" pattern="[-+]?[0-9]*[.,]?[0-9]+" required placeholder="Click to fill!" onBlur="showProgress2()"></ol>
        </div>

        <div>
          <ol for="numberfloat" start="3">
            <li>How many kg of feed does each of your cows eat in one year?
              <div class="toolmark">
                <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-90.png" alt="help">
                <span class="tooltext">
                  Amount of feed eaten by one of the cows on your farm. Data is <b>per year</b> and in <b>KG.</b>
                </span>
              </div>
            </li>
          <input type="number" class="numberfloat" step="any" pattern="[-+]?[0-9]*[.,]?[0-9]+" required placeholder="Click to fill!" onBlur="showProgress3()" maxlenght="5" size="5"></ol>
        </div>

        <div>
          <ol for="numberfloat" start="4">
            <li>How much of your feed is imported?
              <div class="toolmark">
                <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-90.png" alt="help">
                <span class="tooltext">
                  Amount of feed not produced at your farm. Data is <b>per year</b> and in <b>KG.</b>
                </span>
              </div>
            </li>
          <input type="number" class="numberfloat" step="any" pattern="[-+]?[0-9]*[.,]?[0-9]+" required placeholder="Click to fill!" onBlur="showProgress4()"></ol>
        </div>


      <input type="submit" class="button" value="SUBMIT FORM" id="submitbutt">
      </form>

      <div class="progress" id="field1"></div>
    </div>
  </div>

  <!-- MOBILE VERSION !-->
  <div class="container"> <!-- mobile menu !-->
    <div class="content">
      <div role="navigation" id="topbar">
          <div id="menuToggle">
            <input type="checkbox" />
              <span></span>
              <span></span>
              <span></span>
            <nav id="menu">
              <a href="https://arla.antoneliza.dk/"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuCategories.svg" alt="arla logo"><p>Categories</p></a>
              <a href="#"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuStatistics.svg" alt="arla logo"><p>Statistics</p></a>
              <a href="#"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuHelp.svg" alt="arla logo"><p>Help</p></a>
            </nav>
          </div>
          <div id="smallgrid">
            <a href="https://arla.antoneliza.dk/" class="logolink">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/logo.svg" alt="arla logo" id="logo">
            </a>
            <div id="rightnav">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/mobileListIcon.svg" alt="arla logo">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/mobileNavIcon.svg" alt="arla logo">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/searchGreen.svg" alt="arla logo">
            </div>
          </div>
      </div>
    </div>

    <div class="contentscroll" >
      <h1 class="maintitles">Imported Feed</h1>
      <p class="mainparagraphs" id="surveypara">In this section you will be able to fill in all
        the information necessary to calculate the CO2 produced when you import the food for you animals.
      </p>

      <form class="contentflex" id="surveyflexm" action="https://arla.antoneliza.dk/stats-page/" >

        <div>
          <ol for="numberfloat" start="1">
            <li style="font-family: Arla regular;">How many kg of milk does one of your cows produce yearly?

            </li>
          <input type="number" class="numberfloat" step="any" pattern="[-+]?[0-9]*[.,]?[0-9]+" required placeholder="Click to fill!" onBlur="showProgress()"></ol>
        </div>

        <div>
          <ol for="numberfloat" start="2">
            <li style="font-family: Arla regular;">How many kg of milk does one of your cows produce yearly?

            </li>
          <input type="number" class="numberfloat" step="any" pattern="[-+]?[0-9]*[.,]?[0-9]+" required placeholder="Click to fill!" onBlur="showProgress2()"></ol>
        </div>

        <div>
          <ol for="numberfloat" start="3">
            <li style="font-family: Arla regular;">How many kg of milk does one of your cows produce yearly?

            </li>
          <input type="number" class="numberfloat" step="any" pattern="[-+]?[0-9]*[.,]?[0-9]+" required placeholder="Click to fill!" onBlur="showProgress3()"></ol>
        </div>

        <div>
          <ol for="numberfloat" start="4">
            <li style="font-family: Arla regular;">How many kg of milk does one of your cows produce yearly?

            </li>
          <input type="number" class="numberfloat" step="any" pattern="[-+]?[0-9]*[.,]?[0-9]+" required placeholder="Click to fill!" onBlur="showProgress4()"></ol>
        </div>


      <input type="submit" class="button" value="SUBMIT FORM" id="submitbutt">
      </form>

      <div id="onlyheresothatitscrollsnormally"></div>
    </div>

  </div>

  </body>

  <script>
    $('form').on('focus', 'input[type=number]', function (e) {                    // Source: https://stackoverflow.com/questions/9712295/disable-scrolling-on-input-type-number
      $(this).on('wheel.disableScroll', function (e) {
        e.preventDefault()
      })
    })
    $('form').on('blur', 'input[type=number]', function (e) {
      $(this).off('wheel.disableScroll')
    })

    document.getElementById("submitbutt").addEventListener("submit", function(){  // Source: https://stackoverflow.com/questions/41619497/how-to-make-pseudo-class-invalid-apply-to-an-input-after-submitting-a-form/41619669
	  this.className="submitted";
    });


    function showProgress(){
      document.getElementById('field1').style.backgroundImage = 'url(https://arla.antoneliza.dk/wp-content/uploads/2019/10/glass33.svg)';
    }
    function showProgress2(){
      document.getElementById('field1').style.backgroundImage = 'url(https://arla.antoneliza.dk/wp-content/uploads/2019/10/glass66.svg)';
    }
    function showProgress3(){
      document.getElementById('field1').style.backgroundImage = 'url(https://arla.antoneliza.dk/wp-content/uploads/2019/10/glass99.svg)';
    }
    function showProgress4(){
      document.getElementById('field1').style.backgroundImage = 'url(https://arla.antoneliza.dk/wp-content/uploads/2019/10/glass99.svg)';
    }


  </script>
</html>
