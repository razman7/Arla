<?php
  /**
  * Template Name: Final stats
  */
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <style><?php include 'style2.css'; ?> </style>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
    $( function() {
      $( "#tabs" ).tabs();
    } );
    </script>

    <title>Arlagården</title>
  </head>
  <body>
  <!-- DESKTOP VERSION !-->
  <div class="deskwrapper">
    <div class="stickytop"></div>
    <nav class="sidenav"> <!-- desktop menu !-->
      <div>
      <a href="https://arla.antoneliza.dk/" id="home"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/logo.svg" alt="arla logo" style="width: 100px;
  height: 200px;"></a>
      <a href="https://arla.antoneliza.dk/" id="catnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuCategories.svg" alt="arla logo"><p>Categories</p></a>
      <a href="https://arla.antoneliza.dk/final-result/" id="statnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuStatistics.svg" alt="arla logo"><p>Statistics</p></a>
      <a href="#" id="helpnav"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuHelp.svg" alt="arla logo"><p>Help</p></a>
      </div>
    </nav>

    <div class="deskcontent" id="finalwhiteback" style="margin: 0; padding: 0; margin-top: 50px">
      <h1 class="deskmaintitles" id="surveytitle" style="margin-bottom: 20px">You’ve completed the form!</h1>

      <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/image-36.svg" alt="bar graph" class="ssimgl">
      <div id="ffinalsl">
        <h2 class="sshead">CARBON FOOTPRINT</h2>
        <h2 class="sshead" id="sshl">918,46/kg-CO2</h2>
        <p>
          Your carbon footprint has improved by 80% compared to last year.
        </p>
      </div>

      <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Frame-1.svg" alt="bar graph" class="ssimg">
      <div id="ffinals">
        <h2 class="sshead">MONEY MADE</h2>
        <h2 class="sshead" id="sshr">10000 DKK</h2>
        <p>
          We know you’re not doing it for the money, but here’s a little sneak-peak on your bonus for completing the form.
        </p>
      </div>

      <div class="contentflex">
        <div id="tabs">
          <ul>
            <li><a href="#tabs-1">Your carbon footprint in 4 years</a></li>
            <li><a href="#tabs-2">Regional CO2 Emissions </a></li>
            <li><a href="#tabs-3">National CO2 Emissions </a></li>
          </ul>
          <div id="tabs-1">

            <h2>This is how you improved in the past years!</h2>
            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-95.svg" alt="footprints" style="width: 70%; height: auto; display: block; margin-left: auto; margin-right: auto">
            <div class="lines">
              <hr class="line1"> <p class="linetitle">TIPS AND TRICKS</p> <hr class="line2">
            </div>
            <h2>How can you improve even more for the next years?</h2>
            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-98.svg" alt="footprints" style="width: 70%; height: auto; display: block; margin-left: auto; margin-right: auto">
          </div>

          <div id="tabs-2">

            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-99.svg" alt="footprints" style="width: 70%; height: auto; display: block; margin-left: auto; margin-right: auto">
            <div class="lines">
              <hr class="line1"> <p class="linetitle">TIPS AND TRICKS</p> <hr class="line2">
            </div>
            <h2>How can you improve even more for the next years?</h2>
            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-98.svg" alt="footprints" style="width: 70%; height: auto; display: block; margin-left: auto; margin-right: auto">
          </div>

          <div id="tabs-3">
            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-100.svg" alt="footprints" style="width: 70%; height: auto; display: block; margin-left: auto; margin-right: auto">
            <div class="lines">
              <hr class="line1"> <p class="linetitle">TIPS AND TRICKS</p> <hr class="line2">
            </div>
            <h2>How can you improve even more for the next years?</h2>
            <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-98.svg" alt="footprints" style="width: 70%; height: auto; display: block; margin-left: auto; margin-right: auto">
            </div>

        </div>
      </div>

    </div>
  </div>

  <!-- MOBILE VERSION !-->
  <div class="container"> <!-- mobile menu !-->
    <div class="content">
      <div role="navigation" id="topbar">
          <div id="menuToggle">
            <input type="checkbox" />
              <span></span>
              <span></span>
              <span></span>
            <nav id="menu">
              <a href="https://arla.antoneliza.dk/"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuCategories.svg" alt="arla logo"><p>Categories</p></a>
              <a href="https://arla.antoneliza.dk/final-result/"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuStatistics.svg" alt="arla logo"><p>Statistics</p></a>
              <a href="#"><img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/menuHelp.svg" alt="arla logo"><p>Help</p></a>
            </nav>
          </div>
          <div id="smallgrid">
            <a href="#" class="logolink">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/logo.svg" alt="arla logo" id="logo">
            </a>
            <div id="rightnav">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/mobileListIcon.svg" alt="arla logo">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/mobileNavIcon.svg" alt="arla logo">
              <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/searchGreen.svg" alt="arla logo">
            </div>
          </div>
      </div>
    </div>
    
    <div class="contentscroll" >
      <div class="contentflex" id="surveyflexmf">
        <h2 class="maintitles">You’ve completed the form!</h2>
        <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-91.svg" alt="bar graph" class="ssimg" style="display: block; margin-left: auto; margin-right: auto;">


        <div class="lines">
          <hr class="line1"> <p class="linetitle">INPUT STATS</p> <hr class="line2">
        </div>



        <img src="https://arla.antoneliza.dk/wp-content/uploads/2019/10/Group-94.svg" alt="incomplete" style="display: block; margin-left: auto; margin-right: auto;">

        <div id="onlyheresothatitscrollsnormally"></div>
      </div>
    </div>

  </div>

  </body>
</html>
